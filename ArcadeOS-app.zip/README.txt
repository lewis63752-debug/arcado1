ArcadeOS — install as a real app on Chromebook or PC
=====================================================

Chrome will only show the "Install app" option for pages loaded over
http:// or https:// (a security rule for all installable web apps —
not something specific to this file). So you need to serve this folder
from a local server or a free host first. Two easy options:

OPTION A — Run it locally (works on Chromebook and PC)
--------------------------------------------------------
1. Unzip this folder anywhere.
2. Open a terminal in that folder.
   - On a Chromebook: turn on Linux (Settings > Advanced > Developer),
     then open the Linux terminal.
   - On Windows: open PowerShell or Command Prompt in the folder.
3. Run:  python3 -m http.server 8000
   (If "python3" isn't found, try "python".)
4. In Chrome, go to:  http://localhost:8000
5. Click the "Install" icon in the address bar (a monitor with a down
   arrow), or Chrome menu (⋮) > "Cast, save, and share" > "Install page
   as app". ArcadeOS now appears in your app launcher / Start menu and
   opens in its own window, offline-capable, no browser chrome.

OPTION B — Host it for free so you (or anyone) can install it anytime
-------------------------------------------------------------------
1. Create a free GitHub account if you don't have one.
2. Create a new repository and upload all files in this folder
   (index.html, manifest.json, service-worker.js, icon-192.png, icon-512.png).
3. In the repo, go to Settings > Pages > Deploy from branch > main > Save.
4. GitHub gives you a URL like https://yourname.github.io/reponame/
5. Open that URL in Chrome on your Chromebook or PC and click Install,
   same as above. This works from any device without running a server.

Files in this package
----------------------
index.html         - the app itself
manifest.json       - tells Chrome it's installable (name, icon, colors)
service-worker.js   - caches the app so it works offline once installed
icon-192.png / icon-512.png - app icons shown in the launcher/taskbar
